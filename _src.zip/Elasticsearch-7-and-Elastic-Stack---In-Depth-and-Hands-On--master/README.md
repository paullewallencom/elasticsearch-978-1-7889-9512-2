## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/elasticsearch-7-and-elastic-stack-in-depth-and-hands-on-video/9781788995122)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Elasticsearch-7-and-Elastic-Stack---In-Depth-and-Hands-On-
Code Repository for Elasticsearch 7 and Elastic Stack - In Depth and Hands On!, Published by Packt
